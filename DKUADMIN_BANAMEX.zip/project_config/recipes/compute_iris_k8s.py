# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
iris = dataiku.Dataset("iris")
iris_df = iris.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

iris_k8s_df = iris_df # For this sample code, simply copy input to output


# Write recipe outputs
# Dataset iris_k8s renamed to iris_hive by admin on 2024-02-14 17:50:59
iris_k8s = dataiku.Dataset("iris_hive")
iris_k8s.write_with_schema(iris_k8s_df)
